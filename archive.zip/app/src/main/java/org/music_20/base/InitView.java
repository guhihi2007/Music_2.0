package org.music_20.base;

/**
 * Created by Administrator on 2017/4/17.
 */

public interface InitView {
    public void findView();
    public void setListener();
}
